sudo cp tinyedit /usr/local/bin/
