clear && make -f Makefile.amiga clean && make -f Makefile.amiga
