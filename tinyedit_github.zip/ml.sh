clear && make -f Makefile.unix clean && make -f Makefile.unix
