./ml.sh && ./copy.sh
