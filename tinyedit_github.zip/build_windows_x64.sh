#!/bin/sh
clear && make -f Makefile.win32 ARCH=win64 clean && make -f Makefile.win32 ARCH=win64 -j12
