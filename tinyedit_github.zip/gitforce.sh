git reset --hard origin/main
git merge --ff-only origin/main
