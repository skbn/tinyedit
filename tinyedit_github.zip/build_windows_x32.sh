#!/bin/sh
clear && make -f Makefile.win32 ARCH=win32 clean && make -f Makefile.win32 ARCH=win32 -j12
