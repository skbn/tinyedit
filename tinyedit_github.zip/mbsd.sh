gmake -f Makefile.unix clean && gmake -f Makefile.unix
